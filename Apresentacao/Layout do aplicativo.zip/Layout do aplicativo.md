﻿Izabela Naves dos Santos 19/06/2024

O principal objetivo ao desenvolver o layout foi alinhar-se à temática central do grupo, que incorpora a ideia de um "Monster Truck" com uma abordagem simultaneamente robusta e cativante,  evocando  reminiscências  da  infância  feminina  através  de músicas como as da Barbie e da Hello Kitty. Com isso em mente, o design do aplicativo foi concebido em uma paleta de tons variados de rosa.

Recebi o aplicativo da seguinte maneira:

Em tons de cinza, azul, rosa e preto.![](Aspose.Words.d85b7690-9381-43dc-bb52-675d3b17be25.001.jpeg)![](Aspose.Words.d85b7690-9381-43dc-bb52-675d3b17be25.002.jpeg)

Logo em seguida foram feitos os seguintes testes:

- Primeiro teste:![](Aspose.Words.d85b7690-9381-43dc-bb52-675d3b17be25.003.png)
- Segundo Teste:![](Aspose.Words.d85b7690-9381-43dc-bb52-675d3b17be25.004.png)
- Terceiro teste:

![](Aspose.Words.d85b7690-9381-43dc-bb52-675d3b17be25.005.jpeg) ![](Aspose.Words.d85b7690-9381-43dc-bb52-675d3b17be25.006.jpeg)

- Quarto teste:

![](Aspose.Words.d85b7690-9381-43dc-bb52-675d3b17be25.007.jpeg) ![](Aspose.Words.d85b7690-9381-43dc-bb52-675d3b17be25.008.jpeg)

- Resultado final:

![](Aspose.Words.d85b7690-9381-43dc-bb52-675d3b17be25.009.jpeg) ![](Aspose.Words.d85b7690-9381-43dc-bb52-675d3b17be25.010.jpeg)
